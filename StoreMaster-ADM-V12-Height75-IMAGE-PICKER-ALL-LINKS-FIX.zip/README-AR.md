# StoreMaster ADM — V12 Height75 / Width100

هذه النسخة مبنية على StoreMaster V12 المرجعية:

- الارتفاع العمودي: 75% من خط أساس V12 Height90.
- العرض: 100% كما هو.
- نفس ترتيب العناصر والوظائف.
- إصلاح اختيار الصور والملفات داخل ADM عند التشغيل في WebView في تطبيق Android.

## إصلاح اختيار الصور
تمت إضافة `WebChromeClient.onShowFileChooser()` في `MainActivity.java` حتى يعمل عنصر HTML:

`<input type="file" accept="image/*">`

عند الضغط على زر اختيار الصورة، يفتح مدير الملفات/الصور في Android، وبعد اختيار الصورة يعيدها إلى صفحة ADM.

## GitHub Actions
استخدم ملف `main.yml` الموجود مع النسخة لبناء APK عبر GitHub Actions.
